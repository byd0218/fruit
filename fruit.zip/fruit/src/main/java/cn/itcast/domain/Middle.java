package cn.itcast.domain;

public class Middle {

    private Integer middleid;

    private Integer contractid;

    private Integer fruitid;

    private Integer number;

    public Integer getMiddleid() {
        return middleid;
    }

    public void setMiddleid(Integer middleid) {
        this.middleid = middleid;
    }

    public Integer getContractid() {
        return contractid;
    }

    public void setContractid(Integer contractid) {
        this.contractid = contractid;
    }

    public Integer getFruitid() {
        return fruitid;
    }

    public void setFruitid(Integer fruitid) {
        this.fruitid = fruitid;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
